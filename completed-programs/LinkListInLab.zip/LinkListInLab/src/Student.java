
public class Student {
	
	private int idNum;
	private String name;
	
	public Student(String a, int b)
	{
		name = a;
		idNum = b;
	}
	public String getName()
	{
		return name;
	}
	public int getID()
	{
		return idNum;
	}

}
