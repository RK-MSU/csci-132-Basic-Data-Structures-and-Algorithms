package LinkList;


public class Person {
	
	private String name;
	
	public Person(String a)
	{
		name = a;
		
	}
	public String getName()
	{
		return name;
	}	
}
